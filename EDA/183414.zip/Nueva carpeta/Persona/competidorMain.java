import java.util.Enumeration;
import java.util.Hashtable;
import java.io.*;
import java.util.Scanner;

public class competidorMain{
    public  static void main(String[] args) throws IOException{
        Scanner teclado = new Scanner(System.in);
        
        System.out.print("Ingrese el apellido que desea buscar: ");
        String dato = teclado.nextLine();
        System.out.println("Datos: ");
        System.out.println(" ");
        buscarPersona(dato);
        
    }
    public static void buscarPersona(String apellido) throws FileNotFoundException,IOException{
        String auxiliar;
		Enumeration <String> clave = leerArchivo("archivo.txt").keys();
		while (clave.hasMoreElements()) {
			auxiliar = clave.nextElement();
            System.out.println(auxiliar+" = "+leerArchivo("archivo.txt").get(auxiliar).getApellido());
        }
        
        if(leerArchivo("archivo.txt").get(apellido)==null){
            System.out.println(" ");
            System.out.println("El competidor no se encuentra");  
        }
       else{
           System.out.println(" ");
            System.out.println("El competidor es: "+leerArchivo("archivo.txt").get(apellido).getNombre()+" "+leerArchivo("archivo.txt").get(apellido).getApellido()+" "+leerArchivo("archivo.txt").get(apellido).getEdad()+" "+leerArchivo("archivo.txt").get(apellido).getOrigen());
        }
    }

    public static Hashtable <String, Persona> leerArchivo(String nombreArchivo) throws FileNotFoundException,IOException{ 
        Hashtable <String, Persona> t = new Hashtable <String, Persona>();
        String info;
        FileReader archivo = new FileReader(nombreArchivo);
        BufferedReader contenedor = new BufferedReader(archivo);
        while((info = contenedor.readLine())!=null){
            t.put(crearPersona(info).getApellido(), crearPersona(info));
        }
        contenedor.close();
        return t;
    }

    public static Persona crearPersona(String info){
        Persona persona;
        String[] partes;
        partes = info.split(" ");
        int atributoEdad = Integer.parseInt(partes[2]);
        persona = new Persona(partes[0], partes[1], atributoEdad,partes[3]);
        return persona;
    }

   
}