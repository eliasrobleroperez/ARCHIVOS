public interface IEspecialistaCanino{
    long CEDULA_ESPECIALIDAD_CANINOS = 485283;

    String curarCanino();
}