public class Gramatica{
    
}