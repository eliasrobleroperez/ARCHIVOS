public interface IEspecialistaFelino{
    long CEDULA_ESPECIALISTA_FELINIS = 768646;

    String curarFelino();
}